#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

    ofSetFrameRate(60);
    ofBackground(0, 0, 0, 100);
    ofDisableAntiAliasing();
    ofSetVerticalSync(true);
    ofEnableAlphaBlending();
    
    isRunning = false;
    
    /*------------ GUI -------------*/
    myInitialWords.push_back("first");
    myInitialWords.push_back("second");
    myInitialWords.push_back("third");
    
    string test = "test";
    finalWords.push_back(test);
    setGUI1();
//    gui1->loadSettings("gui1Settings.xml");

}

//--------------------------------------------------------------
void ofApp::update(){

    if(isRunning){
        //update however many objects there are in noiseCollection
        for (int i = 0; i < noiseCollection.size(); i++) {
            noiseCollection[i].update();
        }
    }

}

//--------------------------------------------------------------
void ofApp::draw(){
    if(isRunning){
        //draw however many objects there are in noiseCollection
        for (int i = 0; i < noiseCollection.size(); i++) {
            noiseCollection[i].render();
        }
    }
}

void ofApp::startSimulation(){
    
    gui1->toggleVisible();
    
    //create 500 initial NoiseObjects at random positions in the center of the screen
    //and push these back to the noiseCollection vector
    for (int i = 0; i < 500; i++) {
        NoiseObjects newNoise(ofRandom(ofGetWindowWidth()/3, ofGetWindowWidth()/2), ofRandom((2*ofGetWindowHeight())/6, (4*ofGetWindowHeight())/6));
        noiseCollection.push_back(newNoise);
        //cout << newNoise.text << endl;
    }
    
    //start punchCount at 0
    punchCount = 0;
    
    isRunning = true;

}

void ofApp::setGUI1(){
    gui1 = new ofxUISuperCanvas("PANEL 1");
    gui1->setColorBack(ofColor(255, 0, 0, 50));
    
    gui1->addSpacer();
    gui1->setWidgetFontSize(OFX_UI_FONT_MEDIUM);
    gui1->addTextInput("TEXT INPUT", "Input Text")->setAutoClear(true);
    
    gui1->addSpacer();

    // Adding the checkboxes. They're actually toggle buttons, separate widgets
    for(int i = 0; i < myInitialWords.size(); i++){
        gui1->addToggle(myInitialWords[i], false);
    }
    
    gui1->addSpacer();
    
    gui1->addButton("RUN", false);
    
    ofAddListener(gui1->newGUIEvent,this,&ofApp::guiEvent);
}

void ofApp::guiEvent(ofxUIEventArgs &e){
    
    string name = e.getName();
    int kind = e.getKind();
    cout << "got event from: " << name << endl;

    bool isFromCheckbox = false;
    
    // Loop through all words
    for(int i = 0; i < myInitialWords.size(); i++){
        
        if(name == myInitialWords[i]){
            ofxUIToggle *toggle = (ofxUIToggle *) e.widget;
            isFromCheckbox = true;
            
            if (toggle->getValue()) {
                cout << "added" << endl;
//                finalWords.push_back(myInitialWords[i]);

            }else{
                cout << "removed" << endl;                
//              finalWords.erase(myInitialWords.begin() + i);
            }
            cout << name << endl;
            break;
        }
        cout << i << endl;
    }
    
    // All other widgets (text input and run button)
    if(!isFromCheckbox){
        if(name == "TEXT INPUT"){
            ofxUITextInput *ti = (ofxUITextInput *) e.widget;
            if(ti->getInputTriggerType() == OFX_UI_TEXTINPUT_ON_ENTER)
            {
                cout << "ON ENTER: ";
            }
            else if(ti->getInputTriggerType() == OFX_UI_TEXTINPUT_ON_FOCUS)
            {
                cout << "ON FOCUS: ";
            }
            else if(ti->getInputTriggerType() == OFX_UI_TEXTINPUT_ON_UNFOCUS)
            {
                cout << "ON BLUR: ";
            }
            string output = ti->getTextString();
            cout << output << endl;
            
            finalWords.push_back(output);
            
        }else if("RUN"){
            ofxUIButton *button = (ofxUIButton *) e.getButton();
            if(button->getValue()){
                startSimulation();
            }
        }
    }
    
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
//simulating how words will react when integrated into other sketch
//(using a mouse click instead of a "punch")

void ofApp::mousePressed(int x, int y, int button){

    //apply force to all current noiseCollection objects
    for (int i = 0; i < noiseCollection.size(); i++) {
        noiseCollection[i].applyForce();
    }
    
    //increase punch count
    punchCount ++;
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
